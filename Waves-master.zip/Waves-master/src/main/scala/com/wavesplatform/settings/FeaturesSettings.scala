package com.wavesplatform.settings

case class FeaturesSettings(autoShutdownOnUnsupportedFeature: Boolean,
                            supported: List[Short])
