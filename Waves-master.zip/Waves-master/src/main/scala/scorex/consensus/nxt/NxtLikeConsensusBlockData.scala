package scorex.consensus.nxt

import com.wavesplatform.state2.ByteStr

case class NxtLikeConsensusBlockData(baseTarget: Long, generationSignature: ByteStr)
