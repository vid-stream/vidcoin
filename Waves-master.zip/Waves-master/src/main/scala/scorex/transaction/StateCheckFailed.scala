package scorex.transaction

class StateCheckFailed(m: String) extends Error(m)
